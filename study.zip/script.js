"use strict";

// этот код работает в современном режиме
alert("Hello, Frontenders!");